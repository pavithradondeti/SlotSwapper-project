# SlotSwapper (Full Project) — Local Setup

This repository contains a simple full-stack SlotSwapper project (backend + frontend) demonstrating user auth, calendar events, swappable slot marketplace, swap requests and acceptance/rejection.

## Requirements
- Node.js (v14+ recommended)
- npm

## Setup — Backend
1. Open a terminal, go to `backend/`
2. Install dependencies:
   ```bash
   cd backend
   npm install
   ```
3. Initialize DB and seed sample data:
   ```bash
   npm run init-db
   ```
   This creates `slotswapper.db` and inserts two sample users:
   - `alice@example.com` / `password1`
   - `bob@example.com` / `password2`

4. Start backend:
   ```bash
   npm start
   ```
   Server listens on port 3000 by default. You can set `PORT` env variable to change it.

## Setup — Frontend
1. Open a new terminal, go to `frontend/`
2. Install deps:
   ```bash
   cd frontend
   npm install
   ```
3. Start frontend:
   ```bash
   npm start
   ```
   It will open `http://localhost:3000` (React default) — note: backend is `http://localhost:3000/api` in this code. If port conflict occurs, change backend port in `backend/index.js` to 3001 OR change `frontend/src/api.js` base url.

**Important**: If both run on port 3000, change either backend or frontend port:
- To change backend port, set `PORT=3000` (or 3001) before start.
- Or in `frontend/src/api.js` change `base` to `http://localhost:3001/api`.

## How to use (basic flow)
- Signup or login (use seeded user or create new).
- Dashboard -> create events; click "Make Swappable" to offer a slot.
- Marketplace -> view other users' SWAPPABLE slots, choose one and select one of your own swappable slots to offer, then "Request Swap".
- Requests -> incoming/outgoing requests; Accept or Reject incoming.

## API endpoints (summary)
- `POST /api/auth/signup` — { name, email, password } -> { token }
- `POST /api/auth/login` — { email, password } -> { token }
- `GET /api/events` — (auth) returns your events
- `POST /api/events` — create event { title, startTime, endTime }
- `PUT /api/events/:id` — update event (status etc)
- `GET /api/swappable-slots` — list other users' swappable slots
- `POST /api/swap-request` — { mySlotId, theirSlotId } -> creates swap request and sets status SWAP_PENDING on both slots
- `POST /api/swap-response/:id` — { accept: true|false } -> accept or reject
- `GET /api/requests` — get incoming & outgoing

## Notes & assumptions
- Simple SQLite DB used for portability.
- JWT secret defaults to `dev_secret` (use `.env` to override with `JWT_SECRET`).
- The swap accept logic updates `userId` on events so ownership switches; ensures statuses are updated.
- This is a minimal, clear demonstration. For production, add validations, better date handling, tests, and security hardening.

## Next steps & bonuses you can add
- Add WebSocket / Socket.io for real-time notifications.
- Add tests for swap transaction logic (important to avoid race conditions).
- Use Postgres or MongoDB for production.
- Add Dockerfile & docker-compose.


## Docker (optional)

You can run the project with Docker Compose:

```bash
# build and start backend (port 4000) and frontend (port 3000)
docker-compose up --build
```

Frontend will be served at http://localhost:3000 and backend at http://localhost:4000.
