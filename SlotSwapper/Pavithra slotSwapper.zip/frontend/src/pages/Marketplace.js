import React, { useEffect, useState } from 'react';

export default function Marketplace({ api }) {
  const [slots,setSlots] = useState([]);
  const [mySwappables, setMySwappables] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [selectedMySlot, setSelectedMySlot] = useState(null);
  const [msg, setMsg] = useState('');

  async function load() {
    setSlots(await api.getSwappable());
    const me = await api.getMyEvents();
    setMySwappables(me.filter(e => e.status === 'SWAPPABLE'));
  }
  useEffect(()=>{ load(); }, []);

  async function requestSwap() {
    if (!selectedMySlot || !selectedSlot) { setMsg('Select both slots'); return; }
    const res = await api.createSwapRequest({ mySlotId: selectedMySlot.id, theirSlotId: selectedSlot.id });
    setMsg(res.message || (res.id ? 'Request sent' : JSON.stringify(res)));
    load();
  }

  return (
    <div>
      <h2>Marketplace (Swappable Slots)</h2>
      <div style={{display:'flex', gap:20}}>
        <div style={{flex:1}}>
          <h3>Available Slots</h3>
          <ul>
            {slots.map(s => (
              <li key={s.id} style={{border: selectedSlot && selectedSlot.id===s.id ? '1px solid blue' : '1px solid #ddd', padding:6}}>
                <div><strong>{s.title}</strong> — {new Date(s.startTime).toLocaleString()}</div>
                <div>Owner: {s.ownerName}</div>
                <button onClick={()=>setSelectedSlot(s)}>Select this slot</button>
              </li>
            ))}
          </ul>
        </div>

        <div style={{flex:1}}>
          <h3>Your SWAPPABLE Slots</h3>
          <ul>
            {mySwappables.map(m => (
              <li key={m.id} style={{border: selectedMySlot && selectedMySlot.id===m.id ? '1px solid blue' : '1px solid #ddd', padding:6}}>
                <div><strong>{m.title}</strong> — {new Date(m.startTime).toLocaleString()}</div>
                <button onClick={()=>setSelectedMySlot(m)}>Choose this as my offer</button>
              </li>
            ))}
          </ul>
          <div style={{marginTop:10}}>
            <button onClick={requestSwap}>Request Swap</button>
            <div>{msg}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
