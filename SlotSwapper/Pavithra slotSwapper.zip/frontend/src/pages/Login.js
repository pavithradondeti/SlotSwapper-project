import React, { useState } from 'react';

export default function Login({ onLogin, api }) {
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [err,setErr]=useState('');
  async function submit(e) {
    e.preventDefault();
    const res = await api.login({ email, password });
    if (res.token) {
      localStorage.setItem('token', res.token);
      onLogin(res.token);
    } else setErr(res.message || 'Login failed');
  }
  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={submit}>
        <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} /><br/>
        <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><br/>
        <button>Login</button>
      </form>
      <div style={{color:'red'}}>{err}</div>
    </div>
  );
}
