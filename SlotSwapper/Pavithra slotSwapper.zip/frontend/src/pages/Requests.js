import React, { useEffect, useState } from 'react';

export default function Requests({ api }) {
  const [incoming, setIncoming] = useState([]);
  const [outgoing, setOutgoing] = useState([]);
  const [msg, setMsg] = useState('');

  async function load() {
    const res = await api.getRequests();
    setIncoming(res.incoming);
    setOutgoing(res.outgoing);
  }

  useEffect(()=>{ load(); }, []);

  async function respond(id, accept) {
    const r = await api.respond(id, { accept });
    setMsg(JSON.stringify(r));
    load();
  }

  return (
    <div>
      <h2>Requests</h2>
      <div style={{display:'flex', gap:20}}>
        <div style={{flex:1}}>
          <h3>Incoming</h3>
          <ul>
            {incoming.map(i => (
              <li key={i.id}>
                From: {i.requesterId} - My slot: {i.theirSlotId} - Their slot: {i.mySlotId} - Status: {i.status}
                <div>
                  <button onClick={()=>respond(i.id, true)}>Accept</button>
                  <button onClick={()=>respond(i.id, false)}>Reject</button>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div style={{flex:1}}>
          <h3>Outgoing</h3>
          <ul>
            {outgoing.map(o => (
              <li key={o.id}>
                To: {o.requesteeId} - My slot: {o.mySlotId} - Their slot: {o.theirSlotId} - Status: {o.status}
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div>{msg}</div>
    </div>
  );
}
