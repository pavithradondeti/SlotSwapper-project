import React, { useEffect, useState } from 'react';

export default function Dashboard({ api }) {
  const [events,setEvents] = useState([]);
  const [title,setTitle] = useState('');
  const [start,setStart] = useState('');
  const [end,setEnd] = useState('');

  async function load() {
    const res = await api.getMyEvents();
    setEvents(res);
  }

  useEffect(()=>{ load(); }, []);

  async function create(e) {
    e.preventDefault();
    await api.createEvent({ title, startTime: new Date(start).getTime(), endTime: new Date(end).getTime() });
    setTitle(''); setStart(''); setEnd('');
    load();
  }

  async function toggleSwappable(ev) {
    const newStatus = ev.status === 'SWAPPABLE' ? 'BUSY' : 'SWAPPABLE';
    await api.updateEvent(ev.id, { status: newStatus });
    load();
  }

  return (
    <div>
      <h2>My Events</h2>
      <form onSubmit={create}>
        <input placeholder="title" value={title} onChange={e=>setTitle(e.target.value)} />
        <input type="datetime-local" value={start} onChange={e=>setStart(e.target.value)} />
        <input type="datetime-local" value={end} onChange={e=>setEnd(e.target.value)} />
        <button>Create</button>
      </form>
      <ul>
        {events.map(ev => (
          <li key={ev.id}>
            <strong>{ev.title}</strong> — {new Date(ev.startTime).toLocaleString()} to {new Date(ev.endTime).toLocaleString()} — <em>{ev.status}</em>
            <button onClick={()=>toggleSwappable(ev)} style={{marginLeft:8}}>
              {ev.status==='SWAPPABLE' ? 'Unmark Swappable' : 'Make Swappable'}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
