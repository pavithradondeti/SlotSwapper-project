import React, { useState } from 'react';

export default function Signup({ onLogin, api }) {
  const [name,setName]=useState('');
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [err,setErr]=useState('');
  async function submit(e) {
    e.preventDefault();
    const res = await api.signup({ name, email, password });
    if (res.token) {
      localStorage.setItem('token', res.token);
      onLogin(res.token);
    } else setErr(res.message || 'Signup failed');
  }
  return (
    <div>
      <h2>Signup</h2>
      <form onSubmit={submit}>
        <input placeholder="name" value={name} onChange={e=>setName(e.target.value)} /><br/>
        <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} /><br/>
        <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><br/>
        <button>Signup</button>
      </form>
      <div style={{color:'red'}}>{err}</div>
    </div>
  );
}
