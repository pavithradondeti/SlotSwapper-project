// small wrapper for API calls
const API = (token) => {
  const base = 'http://localhost:4000/api'; // backend default port
  const headers = (isJson = true) => {
    const h = {};
    if (isJson) h['Content-Type'] = 'application/json';
    if (token) h['Authorization'] = `Bearer ${token}`;
    return h;
  };

  return {
    signup: (body) => fetch(`${base}/auth/signup`, { method: 'POST', headers: headers(), body: JSON.stringify(body) }).then(r=>r.json()),
    login: (body) => fetch(`${base}/auth/login`, { method: 'POST', headers: headers(), body: JSON.stringify(body) }).then(r=>r.json()),
    getMyEvents: () => fetch(`${base}/events`, { headers: headers() }).then(r=>r.json()),
    createEvent: (body) => fetch(`${base}/events`, { method: 'POST', headers: headers(), body: JSON.stringify(body) }).then(r=>r.json()),
    updateEvent: (id, body) => fetch(`${base}/events/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(body)}).then(r=>r.json()),
    getSwappable: () => fetch(`${base}/swappable-slots`, { headers: headers() }).then(r=>r.json()),
    createSwapRequest: (body) => fetch(`${base}/swap-request`, { method: 'POST', headers: headers(), body: JSON.stringify(body)}).then(r=>r.json()),
    getRequests: () => fetch(`${base}/requests`, { headers: headers() }).then(r=>r.json()),
    respond: (id, body) => fetch(`${base}/swap-response/${id}`, { method: 'POST', headers: headers(), body: JSON.stringify(body)}).then(r=>r.json()),
  };
};

export default API;
