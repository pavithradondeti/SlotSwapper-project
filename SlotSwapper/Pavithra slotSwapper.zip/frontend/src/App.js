import React, { useState, useEffect } from 'react';
import API from './api';
import Nav from './components/Nav';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import Marketplace from './pages/Marketplace';
import Requests from './pages/Requests';

function App() {
  const token0 = localStorage.getItem('token');
  const [token, setToken] = useState(token0);
  const [view, setView] = useState('dashboard');
  const [user, setUser] = useState(null);

  const api = API(token);

  useEffect(()=> {
    if (token) setUser('You');
    else setUser(null);
  }, [token]);

  if (!token) {
    return (
      <div style={{padding:20}}>
        <h1>SlotSwapper</h1>
        <Login onLogin={(t)=>setToken(t)} api={api} />
        <hr />
        <Signup onLogin={(t)=>setToken(t)} api={api} />
      </div>
    );
  }

  return (
    <div>
      <Nav onNav={setView} user={user} />
      <div style={{padding:20}}>
        {view === 'dashboard' && <Dashboard api={api} />}
        {view === 'market' && <Marketplace api={api} />}
        {view === 'requests' && <Requests api={api} />}
      </div>
      <div style={{position:'fixed',right:10,bottom:10}}>
        <button onClick={()=>{ localStorage.removeItem('token'); setToken(null);}}>Logout</button>
      </div>
    </div>
  );
}

export default App;
