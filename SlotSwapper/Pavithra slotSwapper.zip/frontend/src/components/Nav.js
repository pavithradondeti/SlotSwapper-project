import React from 'react';
export default function Nav({ onNav, user }) {
  return (
    <div style={{ padding: 10, borderBottom: '1px solid #ccc', display: 'flex', gap: 10 }}>
      <button onClick={()=>onNav('dashboard')}>Dashboard</button>
      <button onClick={()=>onNav('market')}>Marketplace</button>
      <button onClick={()=>onNav('requests')}>Requests</button>
      <div style={{ marginLeft: 'auto' }}>{user ? `Hi, ${user}` : ''}</div>
    </div>
  );
}
