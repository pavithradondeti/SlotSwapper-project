// init-db.js - create tables and some seed data
const db = require('./db');
const bcrypt = require('bcrypt');

function init() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      email TEXT UNIQUE,
      password TEXT
    );

    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      startTime INTEGER,
      endTime INTEGER,
      status TEXT,
      userId INTEGER,
      FOREIGN KEY(userId) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS swap_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      requesterId INTEGER,
      requesteeId INTEGER,
      mySlotId INTEGER,
      theirSlotId INTEGER,
      status TEXT,
      createdAt INTEGER,
      FOREIGN KEY(requesterId) REFERENCES users(id),
      FOREIGN KEY(requesteeId) REFERENCES users(id),
      FOREIGN KEY(mySlotId) REFERENCES events(id),
      FOREIGN KEY(theirSlotId) REFERENCES events(id)
    );
  `);

  // create two sample users + events if not exists
  const userCount = db.prepare(`SELECT COUNT(*) as c FROM users`).get().c;
  if (userCount === 0) {
    const pwd1 = bcrypt.hashSync('password1', 10);
    const pwd2 = bcrypt.hashSync('password2', 10);
    const insertUser = db.prepare(`INSERT INTO users (name,email,password) VALUES (?,?,?)`);
    const u1 = insertUser.run('Alice', 'alice@example.com', pwd1).lastInsertRowid;
    const u2 = insertUser.run('Bob', 'bob@example.com', pwd2).lastInsertRowid;

    const insertEvent = db.prepare(`INSERT INTO events (title,startTime,endTime,status,userId) VALUES (?,?,?,?,?)`);
    const now = Date.now();
    insertEvent.run('Team Meeting', now + 86400000, now + 86400000 + 3600000, 'BUSY', u1);
    insertEvent.run('Focus Block', now + 2*86400000, now + 2*86400000 + 3600000, 'SWAPPABLE', u2);
  }

  console.log('Database initialized (slotswapper.db)');
}

init();
