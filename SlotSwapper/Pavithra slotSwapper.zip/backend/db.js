// db.js - simple sqlite wrapper
const Database = require('better-sqlite3');
const db = new Database('slotswapper.db');

module.exports = db;
