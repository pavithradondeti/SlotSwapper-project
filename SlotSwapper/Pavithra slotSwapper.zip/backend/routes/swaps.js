// routes/swaps.js - marketplace, requests and responses
const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/auth');

router.use(auth);

/**
 * GET /api/swappable-slots
 * return all slots from other users that are SWAPPABLE
 */
router.get('/swappable-slots', (req, res) => {
  const rows = db.prepare('SELECT e.*, u.name as ownerName FROM events e JOIN users u ON u.id = e.userId WHERE e.status = ? AND e.userId != ?')
    .all('SWAPPABLE', req.user.id);
  res.json(rows);
});

/**
 * POST /api/swap-request
 * body: { mySlotId, theirSlotId }
 */
router.post('/swap-request', (req, res) => {
  const { mySlotId, theirSlotId } = req.body;
  if (!mySlotId || !theirSlotId) return res.status(400).json({ message: 'mySlotId and theirSlotId required' });

  // load slots
  const mySlot = db.prepare('SELECT * FROM events WHERE id = ?').get(mySlotId);
  const theirSlot = db.prepare('SELECT * FROM events WHERE id = ?').get(theirSlotId);
  if (!mySlot || !theirSlot) return res.status(404).json({ message: 'Slot not found' });
  if (mySlot.userId !== req.user.id) return res.status(403).json({ message: 'mySlot does not belong to you' });
  if (mySlot.status !== 'SWAPPABLE' || theirSlot.status !== 'SWAPPABLE') return res.status(400).json({ message: 'Both slots must be SWAPPABLE' });
  if (theirSlot.userId === req.user.id) return res.status(400).json({ message: 'Cannot swap with your own slot' });

  const insert = db.prepare('INSERT INTO swap_requests (requesterId,requesteeId,mySlotId,theirSlotId,status,createdAt) VALUES (?,?,?,?,?,?)');
  const info = insert.run(req.user.id, theirSlot.userId, mySlotId, theirSlotId, 'PENDING', Date.now());
  // set both slots to SWAP_PENDING
  db.prepare('UPDATE events SET status = ? WHERE id IN (?,?)').run('SWAP_PENDING', mySlotId, theirSlotId);

  const row = db.prepare('SELECT * FROM swap_requests WHERE id = ?').get(info.lastInsertRowid);
  res.json(row);
});

/**
 * POST /api/swap-response/:requestId
 * body: { accept: true|false }
 */
router.post('/swap-response/:requestId', (req, res) => {
  const requestId = req.params.requestId;
  const { accept } = req.body;
  const reqRec = db.prepare('SELECT * FROM swap_requests WHERE id = ?').get(requestId);
  if (!reqRec) return res.status(404).json({ message: 'Request not found' });
  if (reqRec.requesteeId !== req.user.id) return res.status(403).json({ message: 'Not authorized to respond' });
  if (reqRec.status !== 'PENDING') return res.status(400).json({ message: 'Request already handled' });

  const mySlot = db.prepare('SELECT * FROM events WHERE id = ?').get(reqRec.mySlotId);      // requester slot
  const theirSlot = db.prepare('SELECT * FROM events WHERE id = ?').get(reqRec.theirSlotId); // requestee slot

  if (accept) {
    // Swap owners: transactionally swap userId of the two events and set both to BUSY
    const tx = db.transaction(() => {
      db.prepare('UPDATE events SET userId = ?, status = ? WHERE id = ?').run(reqRec.requesteeId, 'BUSY', reqRec.mySlotId);
      db.prepare('UPDATE events SET userId = ?, status = ? WHERE id = ?').run(reqRec.requesterId, 'BUSY', reqRec.theirSlotId);
      db.prepare('UPDATE swap_requests SET status = ? WHERE id = ?').run('ACCEPTED', requestId);
    });
    tx();
    res.json({ success: true, status: 'ACCEPTED' });
  } else {
    // Reject: set request to REJECTED and set both slots back to SWAPPABLE
    db.prepare('UPDATE swap_requests SET status = ? WHERE id = ?').run('REJECTED', requestId);
    db.prepare('UPDATE events SET status = ? WHERE id IN (?,?)').run('SWAPPABLE', reqRec.mySlotId, reqRec.theirSlotId);
    res.json({ success: true, status: 'REJECTED' });
  }
});

/**
 * GET /api/requests - returns incoming & outgoing for current user
 */
router.get('/requests', (req, res) => {
  const incoming = db.prepare('SELECT sr.*, u.name AS requesterName FROM swap_requests sr JOIN users u ON u.id = sr.requesterId WHERE sr.requesteeId = ? ORDER BY createdAt DESC').all(req.user.id);
  const outgoing = db.prepare('SELECT sr.*, u.name AS requesteeName FROM swap_requests sr JOIN users u ON u.id = sr.requesteeId WHERE sr.requesterId = ? ORDER BY createdAt DESC').all(req.user.id);
  res.json({ incoming, outgoing });
});

module.exports = router;
