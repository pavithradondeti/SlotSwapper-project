// routes/auth.js
const express = require('express');
const router = express.Router();
const db = require('../db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const SECRET = process.env.JWT_SECRET || 'dev_secret';

router.post('/signup', async (req, res) => {
  const { name, email, password } = req.body;
  if (!email || !password) return res.status(400).json({ message: 'email and password required' });
  const hashed = await bcrypt.hash(password, 10);
  try {
    const info = db.prepare('INSERT INTO users (name,email,password) VALUES (?,?,?)').run(name||'', email, hashed);
    const id = info.lastInsertRowid;
    const token = jwt.sign({ id }, SECRET, { expiresIn: '7d' });
    res.json({ token });
  } catch (e) {
    res.status(400).json({ message: 'User exists or invalid data' });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) return res.status(400).json({ message: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(400).json({ message: 'Invalid credentials' });
  const token = jwt.sign({ id: user.id }, SECRET, { expiresIn: '7d' });
  res.json({ token });
});

module.exports = router;
