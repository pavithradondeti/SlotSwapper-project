// routes/events.js - CRUD for events (user's own)
const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/auth');

router.use(auth);

// create event
router.post('/', (req, res) => {
  const { title, startTime, endTime } = req.body;
  const stmt = db.prepare('INSERT INTO events (title,startTime,endTime,status,userId) VALUES (?,?,?,?,?)');
  const info = stmt.run(title, Number(startTime), Number(endTime), 'BUSY', req.user.id);
  const ev = db.prepare('SELECT * FROM events WHERE id = ?').get(info.lastInsertRowid);
  res.json(ev);
});

// read all user's events
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM events WHERE userId = ?').all(req.user.id);
  res.json(rows);
});

// update event (including status changes)
router.put('/:id', (req, res) => {
  const id = req.params.id;
  const ev = db.prepare('SELECT * FROM events WHERE id = ?').get(id);
  if (!ev || ev.userId !== req.user.id) return res.status(404).json({ message: 'Event not found' });
  const { title, startTime, endTime, status } = req.body;
  db.prepare('UPDATE events SET title = COALESCE(?, title), startTime = COALESCE(?, startTime), endTime = COALESCE(?, endTime), status = COALESCE(?, status) WHERE id = ?')
    .run(title, startTime ? Number(startTime) : undefined, endTime ? Number(endTime) : undefined, status, id);
  const updated = db.prepare('SELECT * FROM events WHERE id = ?').get(id);
  res.json(updated);
});

// delete event
router.delete('/:id', (req, res) => {
  const id = req.params.id;
  const ev = db.prepare('SELECT * FROM events WHERE id = ?').get(id);
  if (!ev || ev.userId !== req.user.id) return res.status(404).json({ message: 'Event not found' });
  db.prepare('DELETE FROM events WHERE id = ?').run(id);
  res.json({ success: true });
});

module.exports = router;
