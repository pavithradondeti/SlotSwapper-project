// index.js - server entry
require('dotenv').config();
const express = require('express');
const app = express();
const cors = require('cors');
const errorHandler = require('./middleware/errorHandler');

const authRoutes = require('./routes/auth');
const eventsRoutes = require('./routes/events');
const swapsRoutes = require('./routes/swaps');

app.use(cors());
app.use(express.json());

// routes
app.use('/api/auth', authRoutes);
app.use('/api/events', eventsRoutes);
app.use('/api', swapsRoutes); // includes swappable-slots, swap-request, swap-response, requests

// simple root
app.get('/', (req, res) => res.send('SlotSwapper Backend is running'));

// error handler
app.use(errorHandler);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
